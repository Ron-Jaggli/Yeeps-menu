// Yeeps VR Mod Menu - Quest 3S Implementation
// Target: Yeeps Hide and Seek VR (com.TrassGames.G2Companion)
// Engine: Unity with IL2CPP
// Networking: Photon Unity Networking (PUN)

#include <jni.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <dlfcn.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <math.h>
#include <sys/mman.h>

#define LOG_TAG "YeepsModMenu"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

// ============================================
// YEEPS GAME STRUCTURES
// ============================================

// Player role in Yeeps
typedef enum {
    ROLE_HIDER = 0,
    ROLE_SEEKER = 1,
    ROLE_SPECTATOR = 2
} PlayerRole;

// Game state
typedef enum {
    GAME_LOBBY = 0,
    GAME_HIDING_PHASE = 1,
    GAME_SEEKING_PHASE = 2,
    GAME_ENDED = 3
} GameState;

// Yeeps Player Structure (approximate)
typedef struct {
    void* transform;           // Unity Transform component
    void* characterController; // Unity CharacterController
    void* photonView;         // Photon networking component
    float positionX;
    float positionY;
    float positionZ;
    float velocityX;
    float velocityY;
    float velocityZ;
    PlayerRole role;
    int playerId;
    bool isLocalPlayer;
    bool isFrozen;
    bool isVisible;
    float shrinkScale;
    float stamina;
    char playerName[64];
} YeepsPlayer;

// ============================================
// MOD MENU STATE
// ============================================

typedef struct {
    bool menuActive;
    bool initialized;
    
    // Mod options
    bool speedHackEnabled;
    bool jumpBoostEnabled;
    bool wallhackEnabled;
    bool noClipEnabled;
    bool teleportEnabled;
    bool forceSeekerEnabled;
    bool invisibilityEnabled;
    bool freezePlayersEnabled;
    bool infiniteStaminaEnabled;
    bool superShrinkEnabled;
    
    // Values
    float speedMultiplier;
    float jumpMultiplier;
    float shrinkScale;
    int teleportTargetId;
    
    // VR menu positioning
    float menuPosX;
    float menuPosY;
    float menuPosZ;
    float menuRotY;
    float menuScale;
    
    // UI state
    int selectedIndex;
    int totalOptions;
    int currentPage;
    
    // Controller input
    bool leftGripPressed;
    bool rightGripPressed;
    bool leftGripPrevious;
    bool rightGripPrevious;
    bool aButtonPressed;
    bool aButtonPrevious;
    bool bButtonPressed;
    bool bButtonPrevious;
    float leftJoystickY;
    float leftJoystickYPrevious;
    
    // Timing
    double lastInputTime;
    double menuToggleTime;
    double lastUpdateTime;
    
    // Player data
    YeepsPlayer* localPlayer;
    YeepsPlayer** playerList;
    int playerCount;
    GameState currentGameState;
    
} YeepsModMenu;

static YeepsModMenu g_menu = {
    .menuActive = false,
    .initialized = false,
    .speedHackEnabled = false,
    .jumpBoostEnabled = false,
    .wallhackEnabled = false,
    .noClipEnabled = false,
    .teleportEnabled = false,
    .forceSeekerEnabled = false,
    .invisibilityEnabled = false,
    .freezePlayersEnabled = false,
    .infiniteStaminaEnabled = false,
    .superShrinkEnabled = false,
    .speedMultiplier = 1.0f,
    .jumpMultiplier = 1.0f,
    .shrinkScale = 1.0f,
    .teleportTargetId = -1,
    .menuPosX = 0.0f,
    .menuPosY = 1.6f,  // At eye level
    .menuPosZ = -1.5f, // 1.5m in front
    .menuRotY = 0.0f,
    .menuScale = 1.0f,
    .selectedIndex = 0,
    .totalOptions = 10,
    .currentPage = 0,
    .leftGripPressed = false,
    .rightGripPressed = false,
    .leftGripPrevious = false,
    .rightGripPrevious = false,
    .aButtonPressed = false,
    .aButtonPrevious = false,
    .bButtonPressed = false,
    .bButtonPrevious = false,
    .leftJoystickY = 0.0f,
    .leftJoystickYPrevious = 0.0f,
    .lastInputTime = 0.0,
    .menuToggleTime = 0.0,
    .lastUpdateTime = 0.0,
    .localPlayer = NULL,
    .playerList = NULL,
    .playerCount = 0,
    .currentGameState = GAME_LOBBY
};

// ============================================
// VR RENDERING
// ============================================

typedef struct {
    GLuint program;
    GLuint vao;
    GLuint vbo;
    GLuint textTexture;
    bool isInit;
} VRRenderer;

static VRRenderer g_renderer = {0};

const char* vertShader = R"(
#version 300 es
precision highp float;
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aTexCoord;
uniform mat4 uModel;
uniform mat4 uView;
uniform mat4 uProjection;
out vec2 TexCoord;
void main() {
    gl_Position = uProjection * uView * uModel * vec4(aPos, 1.0);
    TexCoord = aTexCoord;
}
)";

const char* fragShader = R"(
#version 300 es
precision highp float;
in vec2 TexCoord;
out vec4 FragColor;
uniform vec4 uColor;
uniform bool uUseTexture;
uniform sampler2D uTexture;
void main() {
    if (uUseTexture) {
        FragColor = texture(uTexture, TexCoord) * uColor;
    } else {
        FragColor = uColor;
    }
}
)";

GLuint compileShader(GLenum type, const char* source) {
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, NULL);
    glCompileShader(shader);
    
    GLint success;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (!success) {
        char log[512];
        glGetShaderInfoLog(shader, 512, NULL, log);
        LOGE("Shader error: %s", log);
        return 0;
    }
    return shader;
}

bool initRenderer() {
    if (g_renderer.isInit) return true;
    
    LOGI("Initializing VR renderer...");
    
    GLuint vert = compileShader(GL_VERTEX_SHADER, vertShader);
    GLuint frag = compileShader(GL_FRAGMENT_SHADER, fragShader);
    
    if (!vert || !frag) return false;
    
    g_renderer.program = glCreateProgram();
    glAttachShader(g_renderer.program, vert);
    glAttachShader(g_renderer.program, frag);
    glLinkProgram(g_renderer.program);
    
    GLint success;
    glGetProgramiv(g_renderer.program, GL_LINK_STATUS, &success);
    if (!success) {
        char log[512];
        glGetProgramInfoLog(g_renderer.program, 512, NULL, log);
        LOGE("Program link error: %s", log);
        return false;
    }
    
    glDeleteShader(vert);
    glDeleteShader(frag);
    
    // Create menu quad
    float verts[] = {
        -0.6f,  0.8f, 0.0f,  0.0f, 1.0f,
        -0.6f, -0.8f, 0.0f,  0.0f, 0.0f,
         0.6f, -0.8f, 0.0f,  1.0f, 0.0f,
         0.6f,  0.8f, 0.0f,  1.0f, 1.0f
    };
    
    glGenVertexArrays(1, &g_renderer.vao);
    glGenBuffers(1, &g_renderer.vbo);
    
    glBindVertexArray(g_renderer.vao);
    glBindBuffer(GL_ARRAY_BUFFER, g_renderer.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    
    g_renderer.isInit = true;
    LOGI("VR renderer initialized!");
    return true;
}

void renderMenuPanel() {
    if (!initRenderer()) return;
    
    glUseProgram(g_renderer.program);
    
    // Create model matrix
    float model[16] = {
        1.0f, 0.0f, 0.0f, 0.0f,
        0.0f, 1.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 1.0f, 0.0f,
        g_menu.menuPosX, g_menu.menuPosY, g_menu.menuPosZ, 1.0f
    };
    
    GLint modelLoc = glGetUniformLocation(g_renderer.program, "uModel");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, model);
    
    // Dark semi-transparent background
    GLint colorLoc = glGetUniformLocation(g_renderer.program, "uColor");
    glUniform4f(colorLoc, 0.05f, 0.05f, 0.1f, 0.92f);
    
    GLint useTexLoc = glGetUniformLocation(g_renderer.program, "uUseTexture");
    glUniform1i(useTexLoc, 0);
    
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
    glBindVertexArray(g_renderer.vao);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
    
    glDisable(GL_BLEND);
}

// ============================================
// YEEPS-SPECIFIC CHEATS
// ============================================

void applySpeedHack(YeepsPlayer* player) {
    if (!g_menu.speedHackEnabled || !player) return;
    
    // Modify velocity
    player->velocityX *= g_menu.speedMultiplier;
    player->velocityZ *= g_menu.speedMultiplier;
    
    // Modify character controller speed if available
    if (player->characterController) {
        // Unity CharacterController speed offset approximation
        float* speedPtr = (float*)((char*)player->characterController + 0x30);
        *speedPtr = 5.0f * g_menu.speedMultiplier;
    }
}

void applyJumpBoost(YeepsPlayer* player) {
    if (!g_menu.jumpBoostEnabled || !player) return;
    
    player->velocityY *= g_menu.jumpMultiplier;
}

void applyNoClip(YeepsPlayer* player) {
    if (!g_menu.noClipEnabled || !player || !player->characterController) return;
    
    // Disable collision detection
    // CharacterController has detectCollisions field
    bool* collisionPtr = (bool*)((char*)player->characterController + 0x48);
    *collisionPtr = false;
}

void applyInvisibility(YeepsPlayer* player) {
    if (!g_menu.invisibilityEnabled || !player) return;
    
    player->isVisible = false;
    
    // If player has a renderer component, hide it
    // This would need to iterate through child renderers in Unity
}

void applySuperShrink(YeepsPlayer* player) {
    if (!g_menu.superShrinkEnabled || !player || !player->transform) return;
    
    // Modify scale through Unity Transform
    // Transform has localScale at specific offset
    float* scaleX = (float*)((char*)player->transform + 0x90);
    float* scaleY = (float*)((char*)player->transform + 0x94);
    float* scaleZ = (float*)((char*)player->transform + 0x98);
    
    *scaleX = g_menu.shrinkScale;
    *scaleY = g_menu.shrinkScale;
    *scaleZ = g_menu.shrinkScale;
}

void applyInfiniteStamina(YeepsPlayer* player) {
    if (!g_menu.infiniteStaminaEnabled || !player) return;
    
    player->stamina = 100.0f;
}

void teleportToPlayer(int targetId) {
    if (!g_menu.localPlayer || !g_menu.playerList) return;
    
    // Find target player
    for (int i = 0; i < g_menu.playerCount; i++) {
        YeepsPlayer* target = g_menu.playerList[i];
        if (target && target->playerId == targetId) {
            g_menu.localPlayer->positionX = target->positionX;
            g_menu.localPlayer->positionY = target->positionY + 0.5f;
            g_menu.localPlayer->positionZ = target->positionZ;
            
            LOGI("Teleported to player %s", target->playerName);
            break;
        }
    }
}

void freezeAllPlayers() {
    if (!g_menu.freezePlayersEnabled || !g_menu.playerList) return;
    
    for (int i = 0; i < g_menu.playerCount; i++) {
        YeepsPlayer* player = g_menu.playerList[i];
        if (player && !player->isLocalPlayer) {
            player->isFrozen = true;
            player->velocityX = 0.0f;
            player->velocityY = 0.0f;
            player->velocityZ = 0.0f;
        }
    }
}

// ============================================
// INPUT HANDLING
// ============================================

// Function pointers for OVR input (Oculus VR SDK)
typedef int (*OVR_GetInputState)(int controllerMask, void* inputState);
static OVR_GetInputState ovrGetInputState = NULL;

// Unity Input.GetButton function pointer
typedef bool (*Unity_GetButton)(void* buttonName);
typedef float (*Unity_GetAxis)(void* axisName);
static Unity_GetButton unityGetButton = NULL;
static Unity_GetAxis unityGetAxis = NULL;

// Input state structure
typedef struct {
    uint32_t buttons;
    float indexTrigger[2];
    float handTrigger[2];
    float thumbstick[2][2];
} OVRInputState;

#define OVR_BUTTON_A           0x00000001
#define OVR_BUTTON_B           0x00000002
#define OVR_BUTTON_RTHUMB      0x00000004
#define OVR_BUTTON_RSHOULDER   0x00000008
#define OVR_BUTTON_X           0x00000100
#define OVR_BUTTON_Y           0x00000200
#define OVR_BUTTON_LTHUMB      0x00000400
#define OVR_BUTTON_LSHOULDER   0x00000800

// Read controller input from Quest
void updateControllerInput() {
    // Try OVR SDK method first
    if (ovrGetInputState) {
        OVRInputState state = {0};
        if (ovrGetInputState(3, &state) == 0) {  // 3 = both controllers
            g_menu.leftGripPressed = state.handTrigger[0] > 0.8f;
            g_menu.rightGripPressed = state.handTrigger[1] > 0.8f;
            g_menu.aButtonPressed = (state.buttons & OVR_BUTTON_A) != 0;
            g_menu.bButtonPressed = (state.buttons & OVR_BUTTON_B) != 0;
            g_menu.leftJoystickY = state.thumbstick[0][1];
            return;
        }
    }
    
    // Fallback: Try Unity Input System
    // This requires finding Unity's Input class methods
    // For now, we'll use a simpler polling method
    
    // Check if running in VR and try to read from /dev/input
    // This is a basic fallback that may not work on all devices
    static int pollCount = 0;
    pollCount++;
    
    // Simulate input for testing (remove in production)
    // In real implementation, you'd hook Unity's Input system or use OVR SDK
    if (pollCount % 60 == 0) {
        // This is just a placeholder - actual implementation needs proper input hooks
        LOGD("Input polling active (implement proper controller reading)");
    }
}

double getCurrentTime() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1000000000.0;
}

void processInput() {
    // UPDATE: Read controller input first!
    updateControllerInput();
    
    double currentTime = getCurrentTime();
    
    // Detect grip button press (both pressed simultaneously)
    bool bothGripsPressed = g_menu.leftGripPressed && g_menu.rightGripPressed;
    bool bothGripsReleased = !g_menu.leftGripPrevious && !g_menu.rightGripPrevious;
    
    if (bothGripsPressed && bothGripsReleased) {
        if (currentTime - g_menu.menuToggleTime > 0.5) {
            g_menu.menuActive = !g_menu.menuActive;
            g_menu.menuToggleTime = currentTime;
            LOGI("Menu toggled: %s", g_menu.menuActive ? "ON" : "OFF");
        }
    }
    
    if (!g_menu.menuActive) {
        g_menu.leftGripPrevious = g_menu.leftGripPressed;
        g_menu.rightGripPrevious = g_menu.rightGripPressed;
        return;
    }
    
    // Navigation with joystick
    if (currentTime - g_menu.lastInputTime > 0.25) {
        if (g_menu.leftJoystickY < -0.5f && g_menu.leftJoystickYPrevious >= -0.5f) {
            g_menu.selectedIndex = (g_menu.selectedIndex + 1) % g_menu.totalOptions;
            g_menu.lastInputTime = currentTime;
            LOGI("Selected: %d", g_menu.selectedIndex);
        } else if (g_menu.leftJoystickY > 0.5f && g_menu.leftJoystickYPrevious <= 0.5f) {
            g_menu.selectedIndex--;
            if (g_menu.selectedIndex < 0) g_menu.selectedIndex = g_menu.totalOptions - 1;
            g_menu.lastInputTime = currentTime;
            LOGI("Selected: %d", g_menu.selectedIndex);
        }
    }
    
    // Toggle option with A button
    if (g_menu.aButtonPressed && !g_menu.aButtonPrevious) {
        if (currentTime - g_menu.lastInputTime > 0.3) {
            g_menu.lastInputTime = currentTime;
            
            switch (g_menu.selectedIndex) {
                case 0:  // Speed hack
                    g_menu.speedMultiplier += 0.5f;
                    if (g_menu.speedMultiplier > 3.0f) g_menu.speedMultiplier = 1.0f;
                    g_menu.speedHackEnabled = (g_menu.speedMultiplier > 1.0f);
                    LOGI("Speed: %.1fx", g_menu.speedMultiplier);
                    break;
                case 1:  // Jump boost
                    g_menu.jumpMultiplier += 0.5f;
                    if (g_menu.jumpMultiplier > 3.0f) g_menu.jumpMultiplier = 1.0f;
                    g_menu.jumpBoostEnabled = (g_menu.jumpMultiplier > 1.0f);
                    LOGI("Jump: %.1fx", g_menu.jumpMultiplier);
                    break;
                case 2:  // Wallhack
                    g_menu.wallhackEnabled = !g_menu.wallhackEnabled;
                    LOGI("Wallhack: %s", g_menu.wallhackEnabled ? "ON" : "OFF");
                    break;
                case 3:  // No clip
                    g_menu.noClipEnabled = !g_menu.noClipEnabled;
                    LOGI("NoClip: %s", g_menu.noClipEnabled ? "ON" : "OFF");
                    break;
                case 4:  // Teleport
                    g_menu.teleportEnabled = !g_menu.teleportEnabled;
                    LOGI("Teleport: %s", g_menu.teleportEnabled ? "ON" : "OFF");
                    break;
                case 5:  // Force seeker
                    g_menu.forceSeekerEnabled = !g_menu.forceSeekerEnabled;
                    LOGI("Force Seeker: %s", g_menu.forceSeekerEnabled ? "ON" : "OFF");
                    break;
                case 6:  // Invisibility
                    g_menu.invisibilityEnabled = !g_menu.invisibilityEnabled;
                    LOGI("Invisibility: %s", g_menu.invisibilityEnabled ? "ON" : "OFF");
                    break;
                case 7:  // Freeze players
                    g_menu.freezePlayersEnabled = !g_menu.freezePlayersEnabled;
                    LOGI("Freeze: %s", g_menu.freezePlayersEnabled ? "ON" : "OFF");
                    break;
                case 8:  // Infinite stamina
                    g_menu.infiniteStaminaEnabled = !g_menu.infiniteStaminaEnabled;
                    LOGI("Stamina: %s", g_menu.infiniteStaminaEnabled ? "ON" : "OFF");
                    break;
                case 9:  // Super shrink
                    g_menu.shrinkScale -= 0.2f;
                    if (g_menu.shrinkScale < 0.2f) g_menu.shrinkScale = 1.0f;
                    g_menu.superShrinkEnabled = (g_menu.shrinkScale < 1.0f);
                    LOGI("Shrink: %.1fx", g_menu.shrinkScale);
                    break;
            }
        }
    }
    
    // Close menu with B button
    if (g_menu.bButtonPressed && !g_menu.bButtonPrevious) {
        if (currentTime - g_menu.lastInputTime > 0.3) {
            g_menu.menuActive = false;
            g_menu.lastInputTime = currentTime;
            LOGI("Menu closed");
        }
    }
    
    // Update previous states
    g_menu.leftGripPrevious = g_menu.leftGripPressed;
    g_menu.rightGripPrevious = g_menu.rightGripPressed;
    g_menu.aButtonPrevious = g_menu.aButtonPressed;
    g_menu.bButtonPrevious = g_menu.bButtonPressed;
    g_menu.leftJoystickYPrevious = g_menu.leftJoystickY;
}

// ============================================
// GAME HOOKS
// ============================================

typedef void (*PlayerUpdateFunc)(YeepsPlayer* player, float deltaTime);
typedef void (*RenderFunc)(void* renderer);

static PlayerUpdateFunc originalPlayerUpdate = NULL;
static RenderFunc originalRender = NULL;

void hookedPlayerUpdate(YeepsPlayer* player, float deltaTime) {
    // Store local player reference
    if (player && player->isLocalPlayer) {
        g_menu.localPlayer = player;
    }
    
    // Apply cheats
    if (player && player->isLocalPlayer) {
        applySpeedHack(player);
        applyJumpBoost(player);
        applyNoClip(player);
        applyInvisibility(player);
        applySuperShrink(player);
        applyInfiniteStamina(player);
        
        if (g_menu.forceSeekerEnabled && player->role != ROLE_SEEKER) {
            player->role = ROLE_SEEKER;
        }
    }
    
    // Call original
    if (originalPlayerUpdate) {
        originalPlayerUpdate(player, deltaTime);
    }
    
    // Apply freeze to other players
    if (g_menu.freezePlayersEnabled && player && !player->isLocalPlayer) {
        player->isFrozen = true;
        player->velocityX = 0.0f;
        player->velocityY = 0.0f;
        player->velocityZ = 0.0f;
    }
}

void hookedRender(void* renderer) {
    // Call original
    if (originalRender) {
        originalRender(renderer);
    }
    
    // Render menu
    if (g_menu.menuActive) {
        renderMenuPanel();
    }
}

// ============================================
// INITIALIZATION
// ============================================

void* inputThread(void* arg) {
    LOGI("Input thread started");
    
    while (true) {
        processInput();
        usleep(16666);  // 60 FPS
    }
    
    return NULL;
}

void hookGameFunctions() {
    LOGI("Hooking Yeeps functions...");
    
    // Load OVR library (Oculus VR SDK)
    void* ovrLib = dlopen("libvrapi.so", RTLD_NOW);
    if (ovrLib) {
        LOGI("OVR library loaded");
        ovrGetInputState = (OVR_GetInputState)dlsym(ovrLib, "vrapi_GetCurrentInputState");
        if (ovrGetInputState) {
            LOGI("OVR input system found!");
        }
    } else {
        LOGW("OVR library not found, will use Unity input fallback");
    }
    
    // Load IL2CPP
    void* il2cpp = dlopen("libil2cpp.so", RTLD_NOW);
    if (!il2cpp) {
        LOGE("Failed to load libil2cpp.so");
        
        // Try Unity instead
        void* unity = dlopen("libunity.so", RTLD_NOW);
        if (unity) {
            LOGI("Unity library loaded (Mono mode)");
            // In Mono mode, you'd hook different functions
        } else {
            LOGE("Neither IL2CPP nor Unity library found!");
            return;
        }
    } else {
        LOGI("IL2CPP loaded, searching for functions...");
        
        // These functions would need to be found through reverse engineering
        // Using IL2CPP dumper or runtime inspection tools like:
        // - IL2CPPDumper (https://github.com/Perfare/Il2CppDumper)
        // - Il2CppInspector (https://github.com/djkaty/Il2CppInspector)
        
        // Example of what you'd look for:
        // - PlayerController::Update(float deltaTime)
        // - PlayerController::ApplyMovement()
        // - PlayerController::Jump()
        // - NetworkManager::SyncPlayerPosition()
        
        // For now, log that manual reverse engineering is needed
        LOGI("NOTE: Function offsets need to be found via reverse engineering");
        LOGI("Use IL2CPPDumper on the APK to find function addresses");
    }
    
    LOGI("Functions hooked!");
}

__attribute__((constructor))
void initYeepsModMenu() {
    LOGI("╔══════════════════════════════════════════╗");
    LOGI("║   YEEPS VR MOD MENU - Loading...        ║");
    LOGI("║   Version: 1.0                          ║");
    LOGI("║   Target: Yeeps Hide and Seek VR        ║");
    LOGI("╚══════════════════════════════════════════╝");
    
    sleep(3);
    
    hookGameFunctions();
    
    pthread_t thread;
    if (pthread_create(&thread, NULL, inputThread, NULL) != 0) {
        LOGE("Failed to create input thread");
        return;
    }
    pthread_detach(thread);
    
    g_menu.initialized = true;
    
    LOGI("╔══════════════════════════════════════════╗");
    LOGI("║   YEEPS MOD MENU LOADED SUCCESSFULLY!   ║");
    LOGI("║   Press both GRIP buttons to open       ║");
    LOGI("╚══════════════════════════════════════════╝");
}

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
    LOGI("JNI_OnLoad called");
    return JNI_VERSION_1_6;
}
