#!/bin/bash

# Yeeps VR Mod Menu Injector for Quest 3S
# Specifically designed for Yeeps Hide and Seek VR Game
# Package: com.TrassGames.G2Companion

echo "╔═══════════════════════════════════════════════════╗"
echo "║     YEEPS VR MOD MENU - Quest 3S Injector        ║"
echo "║     Target: Yeeps Hide and Seek VR               ║"
echo "║     Version: 2.14.0 Compatible                   ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""

# Yeeps-specific configuration
PACKAGE_NAME="com.TrassGames.G2Companion"
MOD_MENU_LIB="libyeepsmod.so"
QUEST_TEMP_PATH="/data/local/tmp"
UNITY_LIB="libunity.so"
IL2CPP_LIB="libil2cpp.so"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

log_step() {
    echo -e "${CYAN}[$1]${NC} $2"
}

# Check ADB
check_adb() {
    log_step "1/9" "Checking ADB installation..."
    if ! command -v adb &> /dev/null; then
        log_error "ADB not found!"
        echo ""
        echo "      Install from: https://developer.oculus.com/downloads/"
        exit 1
    fi
    ADB_VERSION=$(adb version | head -n 1)
    log_info "ADB found: $ADB_VERSION"
}

# Check Quest connection
check_device() {
    echo ""
    log_step "2/9" "Checking Quest 3S connection..."
    
    DEVICE_COUNT=$(adb devices | grep -c "device$")
    
    if [ "$DEVICE_COUNT" -eq 0 ]; then
        log_error "No Quest device connected!"
        echo ""
        echo "      Connection steps:"
        echo "      1. Enable Developer Mode in Meta Quest app"
        echo "      2. Connect Quest 3S via USB-C cable"
        echo "      3. Put on headset and allow USB debugging"
        echo "      4. Verify with: adb devices"
        exit 1
    fi
    
    DEVICE_MODEL=$(adb shell getprop ro.product.model 2>/dev/null)
    DEVICE_SERIAL=$(adb get-serialno)
    
    log_info "Device: $DEVICE_MODEL (Serial: $DEVICE_SERIAL)"
    
    # Check if it's actually a Quest
    if [[ ! "$DEVICE_MODEL" =~ "Quest" ]] && [[ ! "$DEVICE_MODEL" =~ "Monterey" ]]; then
        log_warning "Device may not be a Meta Quest headset"
        read -p "Continue anyway? (y/n): " cont
        if [[ ! "$cont" =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
}

# Word pair authentication
await_word_pair() {
    echo ""
    log_step "3/9" "Awaiting activation word pair..."
    echo ""
    echo -e "      ${BLUE}Security Phrase Required${NC}"
    echo "      This prevents accidental injection."
    echo "      Choose 2 words (e.g., 'quantum leap', 'blue dragon')"
    echo ""
    
    while true; do
        read -p "Enter word pair: " WORD1 WORD2
        
        if [ -z "$WORD1" ] || [ -z "$WORD2" ]; then
            log_error "Please enter TWO words separated by space"
            continue
        fi
        
        ACTIVATION_PHRASE="$WORD1 $WORD2"
        echo ""
        read -p "Confirm '$ACTIVATION_PHRASE'? (y/n): " confirm
        
        if [[ "$confirm" =~ ^[Yy]$ ]]; then
            log_info "Activation phrase set: '$ACTIVATION_PHRASE'"
            break
        fi
    done
}

# Check if Yeeps is running
check_yeeps_running() {
    echo ""
    log_step "4/9" "Checking if Yeeps is running..."
    
    PID=$(adb shell "ps -A | grep $PACKAGE_NAME" | awk '{print $2}')
    
    if [ -z "$PID" ]; then
        log_error "Yeeps is not running!"
        echo ""
        echo "      Please launch Yeeps Hide and Seek on your Quest 3S"
        echo ""
        read -p "Press Enter when Yeeps is running, or Ctrl+C to exit..."
        
        PID=$(adb shell "ps -A | grep $PACKAGE_NAME" | awk '{print $2}')
        if [ -z "$PID" ]; then
            log_error "Still not running. Exiting."
            exit 1
        fi
    fi
    
    log_info "Yeeps running (PID: $PID)"
    echo "$PID" > /tmp/yeeps_pid.txt
    
    # Get game version
    GAME_VERSION=$(adb shell "dumpsys package $PACKAGE_NAME | grep versionName" | cut -d'=' -f2 | tr -d '\r')
    if [ -n "$GAME_VERSION" ]; then
        log_info "Game version: $GAME_VERSION"
    fi
}

# Check Unity/IL2CPP
detect_game_engine() {
    echo ""
    log_step "5/9" "Detecting game engine..."
    
    PID=$(cat /tmp/yeeps_pid.txt)
    
    # Check which libraries are loaded
    HAS_UNITY=$(adb shell "cat /proc/$PID/maps 2>/dev/null | grep -q libunity.so && echo yes")
    HAS_IL2CPP=$(adb shell "cat /proc/$PID/maps 2>/dev/null | grep -q libil2cpp.so && echo yes")
    
    if [ "$HAS_IL2CPP" == "yes" ]; then
        log_info "Engine: Unity with IL2CPP"
        ENGINE_TYPE="il2cpp"
    elif [ "$HAS_UNITY" == "yes" ]; then
        log_info "Engine: Unity (Mono)"
        ENGINE_TYPE="mono"
    else
        log_warning "Engine detection unclear, assuming Unity IL2CPP"
        ENGINE_TYPE="il2cpp"
    fi
}

# Push mod menu library
push_library() {
    echo ""
    log_step "6/9" "Pushing Yeeps mod menu to Quest..."
    
    if [ ! -f "$MOD_MENU_LIB" ]; then
        log_error "$MOD_MENU_LIB not found!"
        echo ""
        echo "      Build it first with: ./build_yeeps_mod.sh"
        exit 1
    fi
    
    # Push library
    adb push "$MOD_MENU_LIB" "$QUEST_TEMP_PATH/$MOD_MENU_LIB" > /dev/null 2>&1
    
    if [ $? -ne 0 ]; then
        log_error "Failed to push library"
        exit 1
    fi
    
    adb shell "chmod 755 $QUEST_TEMP_PATH/$MOD_MENU_LIB"
    
    LIB_SIZE=$(ls -lh "$MOD_MENU_LIB" | awk '{print $5}')
    log_info "Library pushed ($LIB_SIZE)"
}

# Detect injection method
prepare_injection() {
    echo ""
    log_step "7/9" "Preparing injection method..."
    
    # Check for root
    HAS_ROOT=$(adb shell "su -c 'echo yes' 2>/dev/null" | tr -d '\r')
    
    if [ "$HAS_ROOT" == "yes" ]; then
        log_info "Root access detected - using ptrace injection"
        INJECTION_METHOD="root"
    else
        log_warning "No root - using LD_PRELOAD (requires restart)"
        INJECTION_METHOD="preload"
    fi
}

# Perform injection
inject_mod_menu() {
    echo ""
    log_step "8/9" "Injecting Yeeps mod menu..."
    
    PID=$(cat /tmp/yeeps_pid.txt)
    
    if [ "$INJECTION_METHOD" == "root" ]; then
        log_info "Performing runtime injection..."
        
        # Create injection helper script
        cat > /tmp/inject_yeeps.sh << 'INJECT_SCRIPT'
#!/system/bin/sh
PID=$1
LIB=$2

# Get libdl.so address for dlopen
DL_ADDR=$(grep "libdl.so" /proc/$PID/maps | head -1 | awk '{print "0x"$1}' | cut -d'-' -f1)

# Attach and inject
gdbserver :5039 --attach $PID &
sleep 1

# Use gdb to call dlopen
gdb -batch \
    -ex "target remote :5039" \
    -ex "call (void*)dlopen(\"$LIB\", 2)" \
    -ex "detach" \
    -ex "quit"

killall gdbserver
INJECT_SCRIPT
        
        adb push /tmp/inject_yeeps.sh "$QUEST_TEMP_PATH/inject.sh" > /dev/null 2>&1
        adb shell "chmod +x $QUEST_TEMP_PATH/inject.sh"
        
        adb shell "su -c '$QUEST_TEMP_PATH/inject.sh $PID $QUEST_TEMP_PATH/$MOD_MENU_LIB'" 2>/dev/null
        
        if [ $? -eq 0 ]; then
            log_info "Runtime injection successful!"
        else
            log_warning "Runtime injection may have failed, trying alternative..."
            INJECTION_METHOD="preload"
        fi
    fi
    
    if [ "$INJECTION_METHOD" == "preload" ]; then
        log_info "Restarting Yeeps with mod menu..."
        
        # Force stop
        adb shell am force-stop "$PACKAGE_NAME"
        sleep 2
        
        # Set wrap property for LD_PRELOAD
        adb shell "setprop wrap.$PACKAGE_NAME 'LD_PRELOAD=$QUEST_TEMP_PATH/$MOD_MENU_LIB'"
        
        # Start game
        adb shell "am start -n $PACKAGE_NAME/com.unity3d.player.UnityPlayerGameActivity"
        
        sleep 3
        log_info "Yeeps restarted with mod menu loaded"
        echo ""
        echo "      ${YELLOW}Put on your Quest headset to continue${NC}"
    fi
}

# Verify and finalize
verify_injection() {
    echo ""
    log_step "9/9" "Verifying injection..."
    
    sleep 3
    
    # Get new PID
    NEW_PID=$(adb shell "ps -A | grep $PACKAGE_NAME" | awk '{print $2}')
    
    if [ -n "$NEW_PID" ]; then
        # Check if our library is loaded
        LOADED=$(adb shell "cat /proc/$NEW_PID/maps 2>/dev/null | grep yeepsmod")
        
        if [ -n "$LOADED" ]; then
            log_info "Mod menu successfully loaded!"
        else
            log_warning "Could not verify injection (mod may still work)"
        fi
    fi
    
    echo ""
    echo "╔═══════════════════════════════════════════════════╗"
    echo "║          YEEPS MOD MENU ACTIVATED!               ║"
    echo "╚═══════════════════════════════════════════════════╝"
    echo ""
    echo -e "${CYAN}═══ IN-GAME CONTROLS ═══${NC}"
    echo ""
    echo "  Open Menu:    ${GREEN}Press BOTH GRIP buttons${NC} (L + R)"
    echo "  Navigate:     ${GREEN}LEFT JOYSTICK${NC} up/down"
    echo "  Toggle:       ${GREEN}A BUTTON${NC} (right controller)"
    echo "  Close Menu:   ${GREEN}B BUTTON${NC}"
    echo ""
    echo -e "${CYAN}═══ AVAILABLE MODS ═══${NC}"
    echo ""
    echo "  ${BLUE}[1]${NC} Speed Hack          - Move faster as seeker/hider"
    echo "  ${BLUE}[2]${NC} Jump Boost          - Jump higher to reach spots"
    echo "  ${BLUE}[3]${NC} Wallhack (ESP)      - See players through walls"
    echo "  ${BLUE}[4]${NC} No Clip             - Walk through objects"
    echo "  ${BLUE}[5]${NC} Teleport to Players - Instant teleport to any player"
    echo "  ${BLUE}[6]${NC} Always Seeker       - Force seeker role"
    echo "  ${BLUE}[7]${NC} Invisibility        - Hide from seekers"
    echo "  ${BLUE}[8]${NC} Freeze Players      - Freeze other players in place"
    echo "  ${BLUE}[9]${NC} Infinite Stamina    - Never get tired"
    echo "  ${BLUE}[10]${NC} Super Shrink       - Become tiny (hider advantage)"
    echo ""
    echo -e "${YELLOW}⚠️  IMPORTANT NOTES:${NC}"
    echo "  • Use responsibly in private games only"
    echo "  • Don't ruin public multiplayer experience"
    echo "  • Remove by restarting game normally"
    echo ""
    echo -e "Activation phrase saved: ${GREEN}$ACTIVATION_PHRASE${NC}"
    echo ""
}

# Main execution
main() {
    check_adb
    check_device
    await_word_pair
    check_yeeps_running
    detect_game_engine
    push_library
    prepare_injection
    inject_mod_menu
    verify_injection
    
    echo "═══════════════════════════════════════════════════"
    echo ""
    echo "View logs: adb logcat -s YeepsModMenu:V"
    echo ""
}

# Cleanup on exit
cleanup() {
    echo ""
    log_info "Cleaning up temporary files..."
    rm -f /tmp/yeeps_pid.txt
    rm -f /tmp/inject_yeeps.sh
}

trap cleanup EXIT

# Run
main
