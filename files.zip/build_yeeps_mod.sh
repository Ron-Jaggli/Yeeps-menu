#!/bin/bash

echo "╔═══════════════════════════════════════════════════╗"
echo "║        YEEPS VR MOD MENU - Builder               ║"
echo "║        Target: Quest 3S / Quest 3                ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""

# Configuration
NDK_PATH="$ANDROID_NDK_HOME"
OUTPUT_DIR="./build"
TARGET_ABI="arm64-v8a"
FINAL_LIB="libyeepsmod.so"

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[$1]${NC} $2"
}

# Check NDK
if [ -z "$NDK_PATH" ]; then
    log_error "Android NDK not found!"
    echo ""
    echo "Install NDK and set ANDROID_NDK_HOME:"
    echo "  1. Download: https://developer.android.com/ndk/downloads"
    echo "  2. Extract to a location"
    echo "  3. Set variable:"
    echo "     export ANDROID_NDK_HOME=/path/to/ndk"
    echo ""
    exit 1
fi

log_info "NDK found: $NDK_PATH"
echo ""

# Check for required files
log_step "1/5" "Checking source files..."

if [ ! -f "yeepsmod.cpp" ]; then
    log_error "yeepsmod.cpp not found!"
    exit 1
fi

if [ ! -f "Android.mk" ]; then
    log_error "Android.mk not found!"
    exit 1
fi

if [ ! -f "Application.mk" ]; then
    log_error "Application.mk not found!"
    exit 1
fi

log_info "All source files present"
echo ""

# Clean old build
log_step "2/5" "Cleaning previous build..."
rm -rf "$OUTPUT_DIR"
rm -f "$FINAL_LIB"
log_info "Build directory cleaned"
echo ""

# Build
log_step "3/5" "Compiling Yeeps mod menu..."
echo ""

$NDK_PATH/ndk-build \
    NDK_PROJECT_PATH=. \
    APP_BUILD_SCRIPT=./Android.mk \
    APP_ABI=$TARGET_ABI \
    APP_PLATFORM=android-29 \
    APP_STL=c++_shared \
    NDK_OUT=$OUTPUT_DIR/obj \
    NDK_LIBS_OUT=$OUTPUT_DIR/libs \
    -j$(nproc)

BUILD_RESULT=$?

echo ""

if [ $BUILD_RESULT -ne 0 ]; then
    log_error "Build failed!"
    echo ""
    echo "Common issues:"
    echo "  • Check NDK version (r25+ recommended)"
    echo "  • Verify source code syntax"
    echo "  • Check Android.mk configuration"
    exit 1
fi

log_info "Build successful!"
echo ""

# Copy library
log_step "4/5" "Copying library..."

if [ ! -f "$OUTPUT_DIR/libs/$TARGET_ABI/libyeepsmod.so" ]; then
    log_error "Output library not found!"
    exit 1
fi

cp "$OUTPUT_DIR/libs/$TARGET_ABI/libyeepsmod.so" "./$FINAL_LIB"

if [ ! -f "./$FINAL_LIB" ]; then
    log_error "Failed to copy library!"
    exit 1
fi

log_info "Library copied: $FINAL_LIB"
echo ""

# Strip and optimize
log_step "5/5" "Optimizing..."

STRIP_TOOL="$NDK_PATH/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip"

if [ ! -f "$STRIP_TOOL" ]; then
    # Try macOS path
    STRIP_TOOL="$NDK_PATH/toolchains/llvm/prebuilt/darwin-x86_64/bin/llvm-strip"
fi

if [ -f "$STRIP_TOOL" ]; then
    $STRIP_TOOL --strip-unneeded "./$FINAL_LIB"
    log_info "Library optimized"
else
    log_info "Strip tool not found (library not optimized)"
fi

FILE_SIZE=$(du -h "./$FINAL_LIB" | cut -f1)
echo ""

echo "╔═══════════════════════════════════════════════════╗"
echo "║           BUILD COMPLETE!                        ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""
echo "Output: $FINAL_LIB ($FILE_SIZE)"
echo ""
echo "Next steps:"
echo "  1. Ensure Yeeps is installed on your Quest 3S"
echo "  2. Connect Quest via USB and enable USB debugging"
echo "  3. Run: chmod +x inject_yeeps_mod.sh"
echo "  4. Run: ./inject_yeeps_mod.sh"
echo ""
