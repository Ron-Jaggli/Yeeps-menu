# Yeeps VR Mod Menu for Quest 3S

An advanced mod menu system for **Yeeps Hide and Seek VR** that injects directly into the game process without modifying any APK files.

```
╔═══════════════════════════════════════════════════╗
║  ⚠️  EDUCATIONAL & PRIVATE USE ONLY              ║
║  Do NOT use in public multiplayer games!         ║
║  This ruins the experience for other players.    ║
╚═══════════════════════════════════════════════════╝
```

## Game Information

- **Game**: Yeeps Hide and Seek VR
- **Package**: `com.TrassGames.G2Companion`
- **Version**: 2.14.0+
- **Engine**: Unity with IL2CPP
- **Networking**: Photon Unity Networking (PUN)
- **Platform**: Meta Quest 3S, Quest 3, Quest 2, Quest Pro

## Features

### 🎮 Gameplay Mods

1. **Speed Hack** (1.0x - 3.0x)
   - Move faster as seeker or hider
   - Adjustable multiplier
   - Perfect for catching hiders or escaping seekers

2. **Jump Boost** (1.0x - 3.0x)
   - Jump higher to reach hiding spots
   - Access normally unreachable areas
   - Great for creative hiding strategies

3. **Wallhack / ESP**
   - See all players through walls
   - Know exactly where everyone is hiding
   - Displays player names and distances

4. **No Clip Mode**
   - Walk through walls and objects
   - Access out-of-bounds areas
   - Hide in impossible locations

5. **Teleport to Players**
   - Instantly teleport to any player
   - Cycle through all players in game
   - Perfect for seekers

6. **Force Seeker Role**
   - Always become the seeker
   - Override random role assignment
   - Practice seeker strategies

7. **Invisibility**
   - Become invisible to other players
   - Hide in plain sight
   - Ultimate hider advantage

8. **Freeze Players**
   - Freeze all other players in place
   - They can't move or hide
   - Complete control over the game

9. **Infinite Stamina**
   - Never get tired
   - Run indefinitely
   - No stamina limitations

10. **Super Shrink** (0.2x - 1.0x)
    - Make yourself tiny
    - Fit in smallest hiding spots
    - Become harder to spot

### 🎨 VR Interface

- **3D Menu in VR Space**
  - Rendered at comfortable viewing distance
  - Semi-transparent dark theme
  - Easy to read in VR

- **Quest Controller Support**
  - Intuitive grip button menu toggle
  - Joystick navigation
  - Button-based selection

- **Non-Intrusive**
  - Menu only visible when active
  - Doesn't interfere with gameplay
  - Clean, professional design

## Requirements

### Hardware
- **Meta Quest 3S** (or Quest 3, Quest 2, Quest Pro)
- **USB-C cable** for ADB connection
- **PC** (Windows, macOS, or Linux)

### Software
- **Android NDK** r25 or newer
- **ADB** (Android Debug Bridge)
- **Developer Mode** enabled on Quest
- **Yeeps** installed on Quest

## Installation & Setup

### Step 1: Enable Developer Mode

1. Open **Meta Quest mobile app** on your phone
2. Tap **Menu** → **Devices** → Select your Quest 3S
3. Tap **Headset Settings**
4. Scroll to **Developer Mode** and toggle it **ON**
5. Accept developer agreement if prompted

### Step 2: Install Development Tools

#### Install ADB

**macOS:**
```bash
brew install android-platform-tools
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt-get install android-tools-adb android-tools-fastboot
```

**Windows:**
Download from: https://developer.android.com/studio/releases/platform-tools

#### Install Android NDK

```bash
# Download NDK from:
https://developer.android.com/ndk/downloads

# Extract and set environment variable
export ANDROID_NDK_HOME=/path/to/android-ndk-r26

# Make it permanent (add to ~/.bashrc or ~/.zshrc)
echo 'export ANDROID_NDK_HOME=/path/to/android-ndk-r26' >> ~/.bashrc
source ~/.bashrc
```

### Step 3: Connect Quest to PC

1. Connect Quest 3S to your PC using USB-C cable
2. Put on the headset
3. You'll see a prompt: **"Allow USB Debugging?"**
4. Check **"Always allow from this computer"**
5. Tap **OK**

Verify connection:
```bash
adb devices
```

Expected output:
```
List of devices attached
1WMHH81234ABCD	device
```

### Step 4: Build the Mod Menu

```bash
# Make build script executable
chmod +x build_yeeps_mod.sh

# Run the build
./build_yeeps_mod.sh
```

The script will:
- Check NDK installation
- Compile the mod menu
- Optimize the library
- Create `libyeepsmod.so`

### Step 5: Launch Yeeps

1. Put on your Quest 3S
2. Launch **Yeeps Hide and Seek** from your library
3. Join or create a game (private recommended)

### Step 6: Inject Mod Menu

```bash
# Make injection script executable
chmod +x inject_yeeps_mod.sh

# Run the injector
./inject_yeeps_mod.sh
```

Follow the prompts:
1. **Device check** - Verifies Quest connection
2. **Word pair** - Enter your security phrase (e.g., "blue dragon")
3. **Game detection** - Finds Yeeps process
4. **Injection** - Patches mod menu into game

## Usage

### Opening the Menu

Press **BOTH GRIP BUTTONS** simultaneously (left + right controller)

### Navigation

- **Left Joystick Up/Down** - Scroll through options
- **A Button** - Toggle/Select option
- **B Button** - Close menu

### Menu Options

```
╔═══════════════════════════════════════════╗
║  YEEPS MOD MENU                          ║
╠═══════════════════════════════════════════╣
║  [>] Speed Hack: 1.5x                    ║
║  [ ] Jump Boost: 1.0x                    ║
║  [ ] Wallhack (ESP): OFF                 ║
║  [ ] No Clip: OFF                        ║
║  [ ] Teleport: OFF                       ║
║  [ ] Force Seeker: OFF                   ║
║  [ ] Invisibility: OFF                   ║
║  [ ] Freeze Players: OFF                 ║
║  [ ] Infinite Stamina: OFF               ║
║  [ ] Super Shrink: 1.0x                  ║
╚═══════════════════════════════════════════╝
```

### Tips & Tricks

**For Hiders:**
- Use **Super Shrink** + **No Clip** to hide in tiny spaces
- Enable **Invisibility** for ultimate stealth
- Use **Speed Hack** to quickly find hiding spots

**For Seekers:**
- Enable **Wallhack/ESP** to see all hiders
- Use **Teleport** to instantly reach players
- **Speed Hack** helps catch runners

**Practice Mode:**
- Use **Force Seeker** to practice seeker role
- **Freeze Players** to explore the map
- **No Clip** to find all hiding spots

## Configuration

### Changing Values

Edit `inject_yeeps_mod.sh` if you want to modify:
- Package name (if game updates)
- Library name
- Temp directory path

Edit `yeepsmod.cpp` to:
- Add custom cheats
- Modify speed multipliers
- Change menu appearance
- Adjust timing values

### Rebuilding

After any code changes:
```bash
./build_yeeps_mod.sh
```

## Troubleshooting

### "No device connected"

**Solution:**
```bash
# Kill and restart ADB server
adb kill-server
adb start-server

# Check devices
adb devices
```

**Check USB cable:**
- Try a different USB-C cable
- Use USB 2.0 port if USB 3.0 causes issues
- Ensure cable supports data transfer (not charge-only)

### "Yeeps is not running"

**Solution:**
1. Launch Yeeps on your Quest 3S
2. Wait for it to fully load
3. Run injection script again

**Verify process:**
```bash
adb shell "ps -A | grep TrassGames"
```

### "Build failed"

**Check NDK:**
```bash
echo $ANDROID_NDK_HOME
# Should show path to NDK directory
```

**Verify NDK version:**
```bash
$ANDROID_NDK_HOME/ndk-build --version
# Should be r25 or newer
```

**Check source files:**
```bash
ls -la yeepsmod.cpp Android.mk Application.mk
# All files should exist
```

### "Injection failed"

**Root method:**
- Most Quest headsets don't have root access
- Script will automatically fallback to LD_PRELOAD method
- This requires restarting Yeeps

**LD_PRELOAD method:**
- Yeeps will restart automatically
- Mod menu loads on startup
- Put on headset to continue

### "Menu doesn't appear"

**Check grip buttons:**
- Press BOTH grip buttons simultaneously
- Hold for ~1 second
- Release both together

**View logs:**
```bash
adb logcat -s YeepsModMenu:V
```

Look for:
```
I/YeepsModMenu: Menu toggled: ON
```

### "Game crashes"

**Clear wrap property:**
```bash
adb shell "setprop wrap.com.TrassGames.G2Companion ''"
```

**Restart Yeeps normally:**
```bash
adb shell am force-stop com.TrassGames.G2Companion
# Launch from Quest menu
```

## Advanced Usage

### Viewing Real-Time Logs

Monitor mod menu activity:
```bash
adb logcat -s YeepsModMenu:V
```

### Checking Memory

View loaded libraries:
```bash
PID=$(adb shell "pidof com.TrassGames.G2Companion")
adb shell "cat /proc/$PID/maps | grep yeeps"
```

### Remote Debugging

For advanced users with GDB:
```bash
# Start gdbserver on Quest
adb shell "su -c 'gdbserver :5039 --attach $PID'"

# Connect from PC
adb forward tcp:5039 tcp:5039
gdb-multiarch -ex "target remote :5039"
```

### Custom Modifications

Edit `yeepsmod.cpp` to add features:

```cpp
// Example: Add custom speed value
case 0:  // Speed hack option
    if (g_menu.speedMultiplier == 1.0f) {
        g_menu.speedMultiplier = 2.0f;  // Your custom value
    } else {
        g_menu.speedMultiplier = 1.0f;
    }
    break;
```

Rebuild after changes:
```bash
./build_yeeps_mod.sh
```

## Removing the Mod Menu

### Method 1: Restart Yeeps

Simply restart Yeeps normally:
```bash
adb shell am force-stop com.TrassGames.G2Companion
# Launch from Quest menu
```

### Method 2: Clear Wrap Property

```bash
adb shell "setprop wrap.com.TrassGames.G2Companion ''"
adb shell am start -n com.TrassGames.G2Companion/com.unity3d.player.UnityPlayerGameActivity
```

### Method 3: Remove Library

```bash
adb shell "rm -f /data/local/tmp/libyeepsmod.so"
```

## Safety & Ethics

### ⚠️ Important Guidelines

**DO:**
- ✅ Use in **private lobbies** with friends who consent
- ✅ Use for **testing and learning** game mechanics
- ✅ Use to **practice** different roles
- ✅ Have **fun responsibly**

**DON'T:**
- ❌ Use in **public multiplayer** games
- ❌ **Ruin experiences** for other players
- ❌ Use to **troll or harass** others
- ❌ **Share** with others who will misuse it

### Why This Matters

Yeeps is a fun, social VR game. Using cheats in public games:
- Ruins the experience for legitimate players
- Makes the game unfair and frustrating
- Can get you banned from the game
- Hurts the VR community

**Use wisely. Play fair. Have fun!**

## Technical Details

### Architecture

```
┌─────────────────────────────────────┐
│   Yeeps VR Game (Unity/IL2CPP)     │
│   com.TrassGames.G2Companion        │
├─────────────────────────────────────┤
│                                     │
│   ┌───────────────────────────┐   │
│   │  libyeepsmod.so (Injected) │   │
│   ├───────────────────────────┤   │
│   │  • Hooks game functions    │   │
│   │  • Renders VR overlay      │   │
│   │  • Processes input         │   │
│   │  • Applies cheats          │   │
│   └───────────────────────────┘   │
│                                     │
├─────────────────────────────────────┤
│   Unity Engine (libunity.so)       │
│   IL2CPP Runtime (libil2cpp.so)    │
└─────────────────────────────────────┘
```

### Injection Methods

**Method 1: Runtime Injection (Root Required)**
- Uses ptrace to attach to process
- Calls dlopen() to load mod menu
- No game restart required
- Instant injection

**Method 2: LD_PRELOAD (No Root)**
- Sets Android wrap property
- Preloads library on game start
- Requires game restart
- Works on unrooted devices

### Memory Hooking

The mod menu hooks key game functions:
- `PlayerUpdate()` - Apply movement cheats
- `RenderFrame()` - Draw menu overlay
- `NetworkSync()` - Modify network data

### OpenGL Rendering

Menu uses OpenGL ES 3.0:
- Vertex shader for positioning
- Fragment shader for colors
- Quad mesh for background
- Alpha blending for transparency

## Development

### Building from Source

Requirements:
- Android NDK r25+
- C++17 compiler
- Make/ndk-build

Build command:
```bash
ndk-build NDK_PROJECT_PATH=. \
  APP_BUILD_SCRIPT=./Android.mk \
  APP_ABI=arm64-v8a
```

### Adding Features

1. Define feature in `YeepsModMenu` struct
2. Add menu option in input handling
3. Implement cheat function
4. Call from `hookedPlayerUpdate()`
5. Rebuild and test

### Reverse Engineering

To find game offsets:
- Use **IL2CPPDumper** for IL2CPP games
- Use **IDA Pro** or **Ghidra** for disassembly
- Use **Frida** for runtime analysis
- Use **GameGuardian** for memory scanning

## FAQ

**Q: Will I get banned?**
A: Possibly, if used in public games. Use private lobbies only.

**Q: Does this work on Quest 2?**
A: Yes, compatible with all Quest headsets.

**Q: Can I use this wirelessly?**
A: Not for injection (needs USB), but once injected, yes.

**Q: Will this work after game updates?**
A: Possibly. Offsets may change with updates. Code may need adjustment.

**Q: Can I add my own cheats?**
A: Yes! Edit `yeepsmod.cpp` and rebuild.

**Q: Is this detectable?**
A: Yes, anti-cheat could detect it. Use responsibly.

## Credits

- **Unity Technologies** - Unity Engine
- **Exit Games** - Photon Networking
- **Meta** - Quest SDK and VR platform
- **Trass Games** - Yeeps Hide and Seek VR

## License

This project is for **educational purposes only**.

Use responsibly. Respect other players. Have fun!

---

**Version:** 1.0  
**Platform:** Meta Quest 3S, Quest 3, Quest 2, Quest Pro  
**Game Version:** 2.14.0+  
**Last Updated:** February 2026
