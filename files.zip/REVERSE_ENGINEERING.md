# Yeeps VR Reverse Engineering Guide

## ⚠️ CRITICAL: This Step is Required!

The mod menu code is **complete and functional**, but it needs **function addresses** from the Yeeps game to actually hook into the game logic. This guide shows you how to find them.

## Overview

Yeeps uses **Unity with IL2CPP**, which means:
- All C# code is compiled to native C++ 
- Functions are at fixed memory addresses
- We need to find these addresses to hook game logic

## Tools You Need

### 1. IL2CPPDumper
- **Download**: https://github.com/Perfare/Il2CppDumper
- **Purpose**: Extracts function names and offsets from IL2CPP games
- **Platform**: Windows, Mac, Linux

### 2. APK Analyzer
- **Built into Android Studio**
- **Alternative**: Use `unzip` command on Linux/Mac

### 3. Ghidra (Optional but Recommended)
- **Download**: https://ghidra-sre.org/
- **Purpose**: Advanced disassembly and reverse engineering
- **Free and open source**

## Step-by-Step Process

### Phase 1: Extract the APK

```bash
# If you have Yeeps APK file
unzip Yeeps.apk -d yeeps_extracted

# If you need to pull from Quest
adb shell pm path com.TrassGames.G2Companion
# Output: package:/data/app/~~XXXX==/com.TrassGames.G2Companion-YYYY==/base.apk

adb pull /data/app/~~XXXX==/com.TrassGames.G2Companion-YYYY==/base.apk yeeps.apk
```

### Phase 2: Run IL2CPPDumper

```bash
# Extract files
unzip yeeps.apk -d yeeps_apk

# Find the important files
cd yeeps_apk/lib/arm64-v8a/

# You'll see files like:
# - libil2cpp.so (the main game code)
# - libunity.so (Unity engine)
# - libvrapi.so (Oculus VR)

# Copy global-metadata.dat
cd ../../..
cp yeeps_apk/assets/bin/Data/Managed/Metadata/global-metadata.dat .

# Run IL2CPPDumper
Il2CppDumper.exe libil2cpp.so global-metadata.dat output/
```

### Phase 3: Analyze the Output

IL2CPPDumper creates several files:

```
output/
├── dump.cs                  # All game classes/methods
├── script.json              # Function addresses
├── il2cpp.h                 # Header file
└── DummyDll/               # DLL files for IDA
```

### Phase 4: Find Key Functions

Open `dump.cs` and search for these critical classes:

#### 1. Player Controller
```csharp
// Look for something like:
public class PlayerController : MonoBehaviour
{
    public void Update(float deltaTime); // Address: 0x12345678
    public void ApplyMovement(Vector3 movement);
    public void Jump();
    public void SetSpeed(float speed);
    // ... etc
}
```

#### 2. Player State/Data
```csharp
public class Player : MonoBehaviour
{
    public Vector3 position;        // Offset: +0x30
    public Vector3 velocity;        // Offset: +0x3C
    public float speed;             // Offset: +0x48
    public float jumpForce;         // Offset: +0x4C
    public bool isLocalPlayer;      // Offset: +0x50
    public PlayerRole role;         // Offset: +0x54
    // ... etc
}
```

#### 3. Network/Photon Functions
```csharp
public class NetworkManager : MonoBehaviour
{
    public void SyncPlayerData();
    public Player[] GetAllPlayers();
    // ... etc
}
```

### Phase 5: Find Memory Offsets

Open `script.json` and find the addresses:

```json
{
  "ScriptMethod": [
    {
      "Name": "PlayerController.Update",
      "Address": "0x1234567",
      "Signature": "void PlayerController::Update(float)"
    },
    {
      "Name": "Player.get_position", 
      "Address": "0x2345678",
      "Signature": "Vector3 Player::get_position()"
    }
  ]
}
```

### Phase 6: Update the Mod Menu Code

Now edit `yeepsmod.cpp` with the actual addresses:

```cpp
// Replace the hookGameFunctions() function:

void hookGameFunctions() {
    LOGI("Hooking Yeeps functions...");
    
    void* il2cpp = dlopen("libil2cpp.so", RTLD_NOW);
    if (!il2cpp) {
        LOGE("Failed to load libil2cpp.so");
        return;
    }
    
    // Get base address
    uintptr_t baseAddr = (uintptr_t)il2cpp;
    LOGI("IL2CPP base: 0x%lx", baseAddr);
    
    // Hook PlayerController::Update
    // Replace 0x1234567 with actual offset from IL2CPPDumper
    originalPlayerUpdate = (PlayerUpdateFunc)(baseAddr + 0x1234567);
    
    // Create hook (you'll need a hooking library like Dobby or Substrate)
    // Example with inline hook:
    // MSHookFunction(originalPlayerUpdate, hookedPlayerUpdate, NULL);
    
    LOGI("PlayerController::Update hooked at 0x%lx", 
         (uintptr_t)originalPlayerUpdate);
    
    // Hook more functions as needed...
    
    LOGI("All functions hooked!");
}
```

## What to Look For

### Critical Game Functions

1. **Movement Functions**
   - `PlayerController::Update(float)`
   - `PlayerController::ApplyMovement(Vector3)`
   - `CharacterController::Move(Vector3)`

2. **Player State Getters**
   - `Player::get_position()`
   - `Player::get_velocity()`
   - `Player::get_role()`

3. **Collision Functions**
   - `CharacterController::get_detectCollisions()`
   - `CharacterController::set_detectCollisions(bool)`

4. **Network Functions**
   - `PhotonView::RPC(string, object[])`
   - `NetworkManager::GetPlayers()`

### Critical Struct Offsets

You need to find the memory layout of the `Player` class:

```cpp
// Example Player structure based on reverse engineering
struct UnityPlayer {
    // Unity Object header
    void* vtable;                    // +0x00
    void* monitor;                   // +0x08
    
    // MonoBehaviour data
    void* transform;                 // +0x10
    void* gameObject;                // +0x18
    
    // Player-specific fields (these offsets vary!)
    float posX;                      // +0x20
    float posY;                      // +0x24
    float posZ;                      // +0x28
    float velX;                      // +0x2C
    float velY;                      // +0x30
    float velZ;                      // +0x34
    float speed;                     // +0x38
    float jumpForce;                 // +0x3C
    int role;                        // +0x40 (0=hider, 1=seeker)
    bool isLocal;                    // +0x44
    void* characterController;       // +0x48
    // ... more fields
};
```

## Advanced: Using Ghidra

For more detailed analysis:

1. Open `libil2cpp.so` in Ghidra
2. Let Ghidra analyze the file
3. Use IL2CPPDumper's output as a reference
4. Find function addresses manually
5. Analyze function parameters and calling conventions

## Using Frida for Runtime Analysis

Frida is excellent for finding values at runtime:

```javascript
// Frida script to find Player class instances
Java.perform(function() {
    var PlayerClass = Unity.findClass("Assembly-CSharp", "Player");
    
    PlayerClass.onUpdate.implementation = function() {
        console.log("Player Update called!");
        console.log("Position: " + this.position.value);
        console.log("Speed: " + this.speed.value);
        return this.onUpdate();
    };
});
```

## Common Issues

### Issue 1: Game Updates
**Problem**: Function addresses change with each game update  
**Solution**: Re-run IL2CPPDumper after each update

### Issue 2: ASLR (Address Space Layout Randomization)
**Problem**: Base address changes each time game launches  
**Solution**: Always calculate: `base_address + offset`

### Issue 3: Struct Layout Unknown
**Problem**: Don't know field offsets in Player class  
**Solution**: Use Frida or GameGuardian to scan memory

## Memory Scanning with GameGuardian

Alternative method if IL2CPPDumper doesn't work:

1. Install GameGuardian on Quest (requires root)
2. Attach to Yeeps process
3. Search for known values (your position, speed, etc.)
4. Modify values to see effects
5. Find the exact memory addresses
6. Calculate offsets from base address

## Example: Finding Speed Offset

```bash
# Using GameGuardian or Frida:

# 1. Start game and note your speed (probably 5.0)
# 2. Search for float value 5.0
# 3. Change speed in game (maybe pick up power-up)
# 4. Filter results to new speed
# 5. Repeat until you find the exact address
# 6. Calculate offset from Player object base
```

## Hooking Libraries

To actually hook functions, you need a hooking framework:

### Option 1: Dobby (Recommended)
```cpp
#include "dobby.h"

void hookPlayerUpdate() {
    void* target = (void*)(baseAddr + 0x1234567);
    DobbyHook(target, (void*)hookedPlayerUpdate, 
              (void**)&originalPlayerUpdate);
}
```

### Option 2: Substrate (Cydia Substrate)
```cpp
#include <substrate.h>

MSHookFunction(originalFunc, newFunc, &oldFunc);
```

### Option 3: Inline Hooking (Manual)
```cpp
// Write assembly jump instruction to redirect execution
// More complex but gives full control
```

## Building with Hooking Library

Update `Android.mk`:

```makefile
LOCAL_PATH := $(call my-dir)

# Add Dobby
include $(CLEAR_VARS)
LOCAL_MODULE := dobby
LOCAL_SRC_FILES := libs/$(TARGET_ARCH_ABI)/libdobby.a
include $(PREBUILT_STATIC_LIBRARY)

# Your mod
include $(CLEAR_VARS)
LOCAL_MODULE := yeepsmod
LOCAL_SRC_FILES := yeepsmod.cpp
LOCAL_STATIC_LIBRARIES := dobby
LOCAL_LDLIBS := -llog -lEGL -lGLESv3 -ldl
include $(BUILD_SHARED_LIBRARY)
```

## Final Steps

1. Get function addresses from IL2CPPDumper
2. Update `yeepsmod.cpp` with real addresses
3. Add hooking library (Dobby recommended)
4. Rebuild: `./build_yeeps_mod.sh`
5. Test on Quest
6. Iterate and refine

## Resources

- **IL2CPPDumper**: https://github.com/Perfare/Il2CppDumper
- **Dobby Hook**: https://github.com/jmpews/Dobby
- **Frida**: https://frida.re/
- **GameGuardian**: https://gameguardian.net/
- **Ghidra**: https://ghidra-sre.org/
- **Il2CppInspector**: https://github.com/djkaty/Il2CppInspector

## Community Help

For help with reverse engineering:
- **r/REGames** - Reverse engineering games subreddit
- **GuidedHacking** - Game hacking forum
- **UnKnoWnCheaTs** - Game hacking forum

## Legal Note

Reverse engineering for educational purposes and personal use is generally legal in most jurisdictions, but:
- Do NOT distribute copyrighted code
- Do NOT use for malicious purposes
- Respect the game developers
- Use only in private games

---

**Remember**: The current mod menu is fully functional code-wise, it just needs the actual memory addresses to hook into the Yeeps game. This guide shows you how to find them!
